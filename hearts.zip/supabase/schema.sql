-- Hearts: run this once in Supabase > SQL Editor > New query > Run.

-- Everyone who can be picked in "Who's playing?"
create table if not exists public.people (
  id        text primary key,             -- lowercase name, e.g. 'ben'
  name      text not null,
  added_at  timestamptz not null default now()
);

-- One row per finished game (reaching 100 or ended early)
create table if not exists public.games (
  id        text primary key,
  ended_at  timestamptz not null default now(),
  early     boolean not null default false,  -- true when "End game now" was used
  hands     int not null default 0,
  players   jsonb not null,                  -- ["Noah","Ben","Kevin","Casey"] in seat order
  finals    jsonb not null,                  -- final totals, same order as players
  winners   jsonb not null,                  -- lowest score (ties share the win)
  moons     jsonb not null default '{}'      -- {"Ben": 1} moon shots in this game
);

-- Wins and moon shots per player, for browsing in the Table Editor
create or replace view public.player_stats as
select p.name,
       count(g.id)                                  as games,
       count(g.id) filter (where g.winners ? p.name) as wins,
       coalesce(sum((g.moons ->> p.name)::int), 0)  as moons
from public.people p
left join public.games g on g.players ? p.name
group by p.name
order by wins desc, moons desc, p.name;

-- The app uses the public "anon" key, so let that key read and write these two tables.
-- Anyone with your app's link can add players and record games. That's fine for a lunch game;
-- don't put anything private in here.
alter table public.people enable row level security;
alter table public.games  enable row level security;

drop policy if exists "hearts read people"  on public.people;
drop policy if exists "hearts add people"   on public.people;
drop policy if exists "hearts edit people"  on public.people;
create policy "hearts read people" on public.people for select to anon using (true);
create policy "hearts add people"  on public.people for insert to anon with check (true);
create policy "hearts edit people" on public.people for update to anon using (true) with check (true);

drop policy if exists "hearts read games"   on public.games;
drop policy if exists "hearts add games"    on public.games;
drop policy if exists "hearts edit games"   on public.games;
drop policy if exists "hearts remove games" on public.games;
create policy "hearts read games"   on public.games for select to anon using (true);
create policy "hearts add games"    on public.games for insert to anon with check (true);
create policy "hearts edit games"   on public.games for update to anon using (true) with check (true);
create policy "hearts remove games" on public.games for delete to anon using (true);  -- "Erase last hand" / "Resume game" un-records a finished game

-- Live updates: new players and finished games show up on everyone's phone without a refresh
do $$ begin
  alter publication supabase_realtime add table public.people;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.games;
exception when duplicate_object then null; end $$;

-- Starting roster
insert into public.people (id, name) values
  ('ben','Ben'), ('noah','Noah'), ('james','James'), ('brodie','Brodie'),
  ('kevin','Kevin'), ('taylor','Taylor'), ('casey','Casey'), ('davin','Davin')
on conflict (id) do nothing;
